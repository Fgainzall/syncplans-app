// src/components/SummaryOnboardingBanner.tsx
"use client";

import React from "react";
import { useRouter } from "next/navigation";

export default function SummaryOnboardingBanner({
  hasEvents,
}: {
  hasEvents: boolean;
}) {
  const router = useRouter();

  // Si ya tiene eventos, no mostramos el banner
  if (hasEvents) return null;

  return (
    <section
      style={{
        marginBottom: 16,
        padding: 14,
        borderRadius: 18,
        border: "1px dashed rgba(255,255,255,0.22)",
        background:
          "linear-gradient(135deg, rgba(56,189,248,0.18), rgba(124,58,237,0.22))",
        boxShadow: "0 18px 50px rgba(0,0,0,0.45)",
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        gap: 12,
        color: "rgba(255,255,255,0.95)",
        flexWrap: "wrap",
      }}
    >
      <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
        <div
          style={{
            fontSize: 12,
            fontWeight: 900,
            letterSpacing: "0.08em",
            textTransform: "uppercase",
            opacity: 0.9,
          }}
        >
          Primer paso
        </div>

        <div style={{ fontSize: 16, fontWeight: 900 }}>
          Crea tu primer grupo y empieza con claridad
        </div>

        <div style={{ fontSize: 13, opacity: 0.85, maxWidth: 460 }}>
          El camino más claro es crear un grupo, invitar a alguien y luego
          guardar el primer evento compartido. Así SyncPlans deja de ser una
          agenda personal y empieza a coordinar de verdad.
        </div>

        <div style={{ display: "flex", gap: 10, marginTop: 8, flexWrap: "wrap" }}>
          <button
            onClick={() =>
              router.push("/events/new/details?type=personal")
            }
            style={{
              padding: "8px 14px",
              borderRadius: 999,
              border: "1px solid rgba(255,255,255,0.3)",
              background:
                "linear-gradient(135deg, rgba(56,189,248,0.7), rgba(124,58,237,0.7))",
              color: "#fff",
              fontWeight: 900,
              cursor: "pointer",
              fontSize: 13,
            }}
          >
            Crear evento personal
          </button>

          <button
            onClick={() => router.push("/groups/new")}
            style={{
              padding: "8px 14px",
              borderRadius: 999,
              border: "1px solid rgba(255,255,255,0.25)",
              background: "rgba(5,8,22,0.4)",
              color: "#fff",
              fontWeight: 800,
              cursor: "pointer",
              fontSize: 13,
            }}
          >
            Crear primer grupo
          </button>
        </div>
      </div>

      <div
        style={{
          fontSize: 12,
          opacity: 0.85,
          padding: "8px 12px",
          borderRadius: 999,
          border: "1px solid rgba(255,255,255,0.28)",
          background: "rgba(5,8,22,0.25)",
          fontWeight: 800,
          whiteSpace: "nowrap",
        }}
      >
        SyncPlans · Una sola verdad compartida
      </div>
    </section>
  );
}