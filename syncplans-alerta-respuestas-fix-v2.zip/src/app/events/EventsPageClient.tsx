
// src/app/events/EventsPageClient.tsx
"use client";

import React, { useCallback, useEffect, useMemo, useState } from "react";
import { useRouter, useSearchParams } from "next/navigation";

import supabase from "@/lib/supabaseClient";
import PremiumHeader from "@/components/PremiumHeader";
import MobileScaffold from "@/components/MobileScaffold";
import Section from "@/components/ui/Section";
import Card from "@/components/ui/Card";
import EventsEmptyState from "@/components/events/EventsEmptyState";
import EventsTimeline from "@/components/EventsTimeline";
import { trackEventOnce, trackScreenView } from "@/lib/analytics";

import {
  getMyEventsInRange,
  deleteEventsByIdsDetailed,
  type DbEventRow,
} from "@/lib/eventsDb";
import { getMyGroups, type GroupRow } from "@/lib/groupsDb";
import { getMyDeclinedEventIds } from "@/lib/eventResponsesDb";
import { filterVisibleEvents } from "@/lib/tempeventVisibility";
import {
  computeVisibleConflicts,
  filterIgnoredConflicts,
  type CalendarEvent,
} from "@/lib/conflicts";
import { getConflictDecisionSnapshot } from "@/lib/decisionEngine";
import { getIgnoredConflictKeys } from "@/lib/conflictPrefs";
import {
  getMyConflictResolutionsMap,
  type Resolution,
} from "@/lib/conflictResolutionsDb";
import { getMyProfile } from "@/lib/profilesDb";
import { hasPremiumAccess } from "@/lib/premium";

type ViewMode = "upcoming" | "history" | "all";
type Scope = "personal" | "groups" | "all";

type FilterState = {
  view: ViewMode;
  scope: Scope;
  query: string;
};

type EventWithGroup = DbEventRow & {
  group?: GroupRow | null;
};

function toConflictCalendarEvent(event: EventWithGroup): CalendarEvent | null {
  const id = String(event.id ?? "").trim();
  const start = String(event.start ?? "").trim();
  const end = String(event.end ?? "").trim();

  if (!id || !start || !end) return null;

  return {
    id,
    title: String(event.title ?? "Sin título"),
    start,
    end,
    groupType: event.group?.type ?? (event.group_id ? "other" : "personal"),
    groupId: event.group_id ?? null,
    notes: event.notes ?? undefined,
  };
}

type SegmentOption<T extends string> = {
  value: T;
  label: string;
};

type InboxLaneAction = "attention" | "conflicts" | "upcoming" | "history";
type FocusAsideAction = "upcoming" | "conflicts" | "create" | "focused";

type FocusAsideState = {
  eyebrow: string;
  title: string;
  body: string;
  cta?: string;
  action?: FocusAsideAction;
};

function SegmentedChips<T extends string>({
  options,
  value,
  onChange,
}: {
  options: SegmentOption<T>[];
  value: T;
  onChange: (next: T) => void;
}) {
  return (
    <div style={S.segmentedWrap}>
      {options.map((option) => {
        const active = option.value === value;

        return (
          <button
            key={option.value}
            type="button"
            onClick={() => onChange(option.value)}
            style={{
              ...S.segmentedChip,
              ...(active ? S.segmentedChipActive : null),
            }}
          >
            {option.label}
          </button>
        );
      })}
    </div>
  );
}


function localDateKey(value: string | Date) {
  const d = value instanceof Date ? value : new Date(value);
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function isWithinNext24Hours(value: string | Date) {
  const now = new Date();
  const d = value instanceof Date ? value : new Date(value);
  const diff = d.getTime() - now.getTime();
  return diff >= 0 && diff <= 24 * 60 * 60 * 1000;
}

function shortDateLabel(value: string | Date) {
  const d = value instanceof Date ? value : new Date(value);
  const now = new Date();

  const todayKey = localDateKey(now);
  const tomorrow = new Date(now);
  tomorrow.setDate(now.getDate() + 1);

  const dateKey = localDateKey(d);

  if (dateKey === todayKey) return "Hoy";
  if (dateKey === localDateKey(tomorrow)) return "Mañana";

  return `${String(d.getDate()).padStart(2, "0")}/${String(
    d.getMonth() + 1
  ).padStart(2, "0")}`;
}

function shortTimeLabel(value: string | Date) {
  const d = value instanceof Date ? value : new Date(value);
  return d.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
  });
}

const MOBILE_BREAKPOINT = 768;
const MOBILE_INITIAL_VISIBLE = 8;
const MOBILE_LOAD_MORE_STEP = 8;
const EVENTS_UPCOMING_PAST_DAYS = 2;
const EVENTS_UPCOMING_FUTURE_DAYS = 365;
const EVENTS_HISTORY_PAST_DAYS = 180;
const EVENTS_ALL_PAST_DAYS = 180;
const EVENTS_ALL_FUTURE_DAYS = 365;

function getEventsWindowForView(view: ViewMode) {
  const start = new Date();
  start.setHours(0, 0, 0, 0);

  const end = new Date();
  end.setHours(23, 59, 59, 999);

  if (view === "history") {
    start.setDate(start.getDate() - EVENTS_HISTORY_PAST_DAYS);
    return { startIso: start.toISOString(), endIso: end.toISOString() };
  }

  if (view === "all") {
    start.setDate(start.getDate() - EVENTS_ALL_PAST_DAYS);
    end.setDate(end.getDate() + EVENTS_ALL_FUTURE_DAYS);
    return { startIso: start.toISOString(), endIso: end.toISOString() };
  }

  start.setDate(start.getDate() - EVENTS_UPCOMING_PAST_DAYS);
  end.setDate(end.getDate() + EVENTS_UPCOMING_FUTURE_DAYS);

  return { startIso: start.toISOString(), endIso: end.toISOString() };
}

async function getEventsForView(view: ViewMode): Promise<DbEventRow[]> {
  const { startIso, endIso } = getEventsWindowForView(view);
  return getMyEventsInRange(startIso, endIso);
}

export default function EventsPage() {
  const router = useRouter();
  const searchParams = useSearchParams();

  const [booting, setBooting] = useState(true);
  const [loading, setLoading] = useState(true);

  const [events, setEvents] = useState<EventWithGroup[]>([]);
  const [loadedView, setLoadedView] = useState<ViewMode>("upcoming");
  const [hiddenEventIds] = useState<Set<string>>(() => new Set());
  const [declinedEventIds, setDeclinedEventIds] = useState<Set<string>>(
    () => new Set()
  );
  const [resolvedConflictMap, setResolvedConflictMap] = useState<Record<string, Resolution>>({});
  const [ignoredConflictKeys, setIgnoredConflictKeys] = useState<Set<string>>(
    () => new Set()
  );
  const [groups, setGroups] = useState<GroupRow[]>([]);

  const [filters, setFilters] = useState<FilterState>({
    view: "upcoming",
    scope: "all",
    query: "",
  });

  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());

  const [sendingDigest, setSendingDigest] = useState(false);
  const [deleting, setDeleting] = useState(false);
  const [isMobile, setIsMobile] = useState(false);
  const [mobileVisibleCount, setMobileVisibleCount] = useState(MOBILE_INITIAL_VISIBLE);

  const [toast, setToast] = useState<{
    type: "success" | "error";
    message: string;
  } | null>(null);
  const [hasPremium, setHasPremium] = useState(false);
  const [showAdvancedActions, setShowAdvancedActions] = useState(false);
  const focusMode = searchParams.get("focus");
  const focusedEventId = searchParams.get("focusEventId");
  const isPendingResponsesFocus = focusMode === "pending-responses";

  useEffect(() => {
    if (typeof window === "undefined") return;

    const syncViewport = () => setIsMobile(window.innerWidth < MOBILE_BREAKPOINT);
    syncViewport();
    window.addEventListener("resize", syncViewport);
    return () => window.removeEventListener("resize", syncViewport);
  }, []);

  useEffect(() => {
    void trackScreenView({
      screen: "events",
      metadata: {
        source: isPendingResponsesFocus
          ? "pending_response_focus"
          : focusedEventId
            ? "focused_event"
            : "events_tab",
        focusedEventId: focusedEventId ?? null,
        focusMode: focusMode ?? null,
      },
    });
  }, [focusMode, focusedEventId, isPendingResponsesFocus]);

  useEffect(() => {
    let alive = true;

    async function boot() {
      try {
        const { data } = await supabase.auth.getSession();
        if (!data.session?.user) {
          router.replace("/auth/login");
          return;
        }

        const [
          eventsRes,
          groupsRes,
          declinedRes,
          conflictResMap,
          ignoredKeys,
          profileRes,
        ] = await Promise.all([
          getEventsForView("upcoming").catch((err) => {
            console.error("Error getMyEventsInRange en /events:", err);
            return [] as DbEventRow[];
          }),
          getMyGroups().catch((err) => {
            console.error("Error getMyGroups en /events:", err);
            return [] as GroupRow[];
          }),
          getMyDeclinedEventIds().catch((err) => {
            console.error("Error getMyDeclinedEventIds en /events:", err);
            return new Set<string>();
          }),
          getMyConflictResolutionsMap().catch((err) => {
            console.error("Error getMyConflictResolutionsMap en /events:", err);
            return {};
          }),
          getIgnoredConflictKeys().catch((err) => {
            console.error("Error getIgnoredConflictKeys en /events:", err);
            return new Set<string>();
          }),
          getMyProfile().catch((err) => {
            console.error("Error getMyProfile en /events:", err);
            return null;
          }),
        ]);

        if (!alive) return;

        const groupsById = new Map(groupsRes.map((g) => [String(g.id), g]));

        const withGroup: EventWithGroup[] = eventsRes.map((e) => ({
          ...e,
          group: e.group_id ? groupsById.get(String(e.group_id)) ?? null : null,
        }));

        setEvents(withGroup);
        setGroups(groupsRes);
        setDeclinedEventIds(declinedRes);
        setResolvedConflictMap(conflictResMap ?? {});
        setIgnoredConflictKeys(ignoredKeys instanceof Set ? ignoredKeys : new Set());
        setLoadedView("upcoming");
        setHasPremium(hasPremiumAccess(profileRes));
      } catch (err) {
        console.error("Error booting events:", err);
      } finally {
        if (!alive) return;
        setBooting(false);
        setLoading(false);
      }
    }

    void boot();

    return () => {
      alive = false;
    };
  }, [router]);

  const totalGroups = groups.length;

  const filteredEvents = useMemo(() => {
    let list = filterVisibleEvents(events, {
      declinedIds: declinedEventIds,
      hiddenIds: hiddenEventIds,
    });

    const now = new Date();

    if (filters.view === "upcoming") {
      list = list.filter((e) => new Date(e.start) >= now);
      list.sort((a, b) => +new Date(a.start) - +new Date(b.start));
    } else if (filters.view === "history") {
      list = list.filter((e) => new Date(e.end) < now);
      list.sort((a, b) => +new Date(b.start) - +new Date(a.start));
    } else {
      list.sort((a, b) => +new Date(a.start) - +new Date(b.start));
    }

    if (filters.scope === "personal") {
      list = list.filter((e) => !e.group_id);
    } else if (filters.scope === "groups") {
      list = list.filter((e) => !!e.group_id);
    }

    const q = filters.query.trim().toLowerCase();
    if (q) {
      list = list.filter((e) => {
        const title = String(e.title ?? "").toLowerCase();
        const notes = String(e.notes ?? "").toLowerCase();
        const groupName = String(e.group?.name ?? "").toLowerCase();
        return title.includes(q) || notes.includes(q) || groupName.includes(q);
      });
    }

    return list;
  }, [events, declinedEventIds, hiddenEventIds, filters]);

  const urgentEvents = useMemo(() => {
    if (filters.view === "history") return [];
    return filteredEvents.filter((e) => isWithinNext24Hours(e.start));
  }, [filteredEvents, filters.view]);

  const coordinationInbox = useMemo(() => {
    const now = new Date();
    const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

    const visibleEvents = filterVisibleEvents(events, {
      declinedIds: declinedEventIds,
      hiddenIds: hiddenEventIds,
    });

    const upcomingEvents = visibleEvents.filter((event) => new Date(event.start) >= now);
    const historyEvents = visibleEvents.filter((event) => new Date(event.end) < now);

    const eventsForConflictEngine = upcomingEvents
      .map(toConflictCalendarEvent)
      .filter(Boolean) as CalendarEvent[];

    const pendingConflicts = filterIgnoredConflicts(
      computeVisibleConflicts(eventsForConflictEngine),
      ignoredConflictKeys
    ).filter((conflict) => {
      const snapshot = getConflictDecisionSnapshot({
        conflict: {
          id: conflict.id,
          existing: conflict.existingEventId,
          incoming: conflict.incomingEventId,
        },
        resolvedConflictMap,
      });

      return snapshot.isPending;
    });

    const actionRequiredIds = new Set<string>();

    for (const conflict of pendingConflicts) {
      actionRequiredIds.add(String(conflict.existingEventId));
      actionRequiredIds.add(String(conflict.incomingEventId));
    }

    for (const event of upcomingEvents) {
      const eventId = String(event.id);
      const start = new Date(event.start);

      if (isWithinNext24Hours(start)) {
        actionRequiredIds.add(eventId);
      }

      if (event.group_id && start <= nextWeek) {
        actionRequiredIds.add(eventId);
      }
    }

    const sharedUpcomingCount = upcomingEvents.filter((event) => !!event.group_id).length;

    return {
      actionRequiredCount: actionRequiredIds.size,
      conflictEventCount: pendingConflicts.length,
      upcomingCount: upcomingEvents.length,
      historyCount: historyEvents.length,
      sharedUpcomingCount,
    };
  }, [events, declinedEventIds, hiddenEventIds, ignoredConflictKeys, resolvedConflictMap]);

  const inboxLanes = useMemo<Array<{
    action: InboxLaneAction;
    eyebrow: string;
    title: string;
    count: number;
    body: string;
    accent: "decision" | "conflict" | "upcoming" | "history";
  }>>(() => {
    return [
      {
        action: "attention",
        eyebrow: "Acción",
        title: coordinationInbox.actionRequiredCount > 0 ? "Revisar" : "Todo al día",
        count: coordinationInbox.actionRequiredCount,
        body:
          coordinationInbox.actionRequiredCount > 0
            ? "Acciones abiertas"
            : "Nada pendiente",
        accent: "decision",
      },
      {
        action: "conflicts",
        eyebrow: "Choques",
        title: coordinationInbox.conflictEventCount > 0 ? "Resolver" : "Sin conflictos",
        count: coordinationInbox.conflictEventCount,
        body:
          coordinationInbox.conflictEventCount > 0
            ? "Requieren decisión"
            : "Sin choques",
        accent: "conflict",
      },
      {
        action: "upcoming",
        eyebrow: "Próximos",
        title: "Lo que viene",
        count: coordinationInbox.upcomingCount,
        body: coordinationInbox.upcomingCount > 0 ? "Planes activos" : "Sin planes",
        accent: "upcoming",
      },
      {
        action: "history",
        eyebrow: "Historial",
        title: "Cerrados",
        count: coordinationInbox.historyCount,
        body: coordinationInbox.historyCount > 0 ? "Ya cerrados" : "Sin historial",
        accent: "history",
      },
    ];
  }, [coordinationInbox]);

  const timelineEvents = useMemo(() => {
    if (!isMobile) return filteredEvents;
    return filteredEvents.slice(0, mobileVisibleCount);
  }, [filteredEvents, isMobile, mobileVisibleCount]);

  const pendingResponseEvent = useMemo(() => {
    if (!focusedEventId) return null;

    return (
      events.find((event) => String(event.id) === String(focusedEventId)) ?? null
    );
  }, [events, focusedEventId]);

  const hasMoreTimelineEvents =
    isMobile && filteredEvents.length > timelineEvents.length;

  const statusSnapshot = useMemo(() => {
    const now = new Date();
    const nextWeek = new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000);

    const visibleEvents = filterVisibleEvents(events, {
      declinedIds: declinedEventIds,
      hiddenIds: hiddenEventIds,
    });

    const nextCount = visibleEvents.filter((e) => new Date(e.start) >= now).length;
    const responseCount = visibleEvents.filter(
      (e) => !!e.group_id && new Date(e.start) >= now
    ).length;
    const resolvedCount = visibleEvents.filter((e) => new Date(e.end) < now).length;
    const soonCount = visibleEvents.filter((e) => {
      const start = new Date(e.start);
      return start >= now && start <= nextWeek;
    }).length;

    return { nextCount, responseCount, resolvedCount, soonCount };
  }, [events, declinedEventIds, hiddenEventIds]);

  const valueVisibility = useMemo(() => {
    const visibleEvents = filterVisibleEvents(events, {
      declinedIds: declinedEventIds,
      hiddenIds: hiddenEventIds,
    });

    const personalCount = visibleEvents.filter((e) => !e.group_id).length;
    const groupCount = visibleEvents.filter((e) => !!e.group_id).length;
    const next24h = visibleEvents.filter((e) => isWithinNext24Hours(e.start)).length;

    return {
      personalCount,
      groupCount,
      next24h,
      hasValue: visibleEvents.length > 0,
    };
  }, [events, declinedEventIds, hiddenEventIds]);

  const premiumContext = useMemo(() => {
    const sharedDensity = valueVisibility.groupCount;
    const next24h = valueVisibility.next24h;
    const hasSharedCoordination = totalGroups > 0 || sharedDensity > 0;

    if (hasPremium) return null;
    if (!valueVisibility.hasValue && totalGroups === 0) return null;

    const shouldShow =
      next24h > 0 ||
      statusSnapshot.soonCount >= 3 ||
      sharedDensity >= 2 ||
      totalGroups >= 1;

    if (!shouldShow) return null;

    if (next24h > 0) {
      return {
        variant: "urgency" as const,
        eyebrow: "Premium cuando más importa",
        title: "Cuando tu semana se aprieta, Premium te ayuda a ver antes dónde conviene entrar.",
        body:
          "Más claridad compartida, menos idas y vueltas y mejor contexto para decidir qué mover antes de que el ruido vuelva a aparecer.",
        cta: "Ver ventajas Premium",
      };
    }

    if (hasSharedCoordination) {
      return {
        variant: "shared" as const,
        eyebrow: "Más valor compartido",
        title: "Cuando más gente y más planes viven aquí, Premium empieza a sentirse lógico.",
        body:
          "Te ayuda a coordinar con más claridad, anticipar mejor y convertir actividad compartida en menos fricción real.",
        cta: "Explorar Premium",
      };
    }

    return {
      variant: "momentum" as const,
      eyebrow: "Más claridad operativa",
      title: "Ya estás usando SyncPlans de verdad. Premium lo vuelve todavía más claro.",
      body:
        "No cambia tu flujo free: lo mejora con más contexto, mejor lectura del tiempo compartido y decisiones más rápidas.",
      cta: "Conocer Premium",
    };
  }, [hasPremium, statusSnapshot.soonCount, totalGroups, valueVisibility]);

  useEffect(() => {
    if (!premiumContext) return;

    void trackEventOnce({
      event: "premium_viewed",
      scope: "local",
      onceKey: `events:premium_viewed:${premiumContext.variant}:${focusedEventId ?? "all"}`,
      metadata: {
        source: "events",
        variant: premiumContext.variant,
        focusedEventId: focusedEventId ?? null,
        totalGroups,
        sharedGroupCount: valueVisibility.groupCount,
        next24hCount: valueVisibility.next24h,
        upcomingCount: statusSnapshot.soonCount,
      },
    });
  }, [
    premiumContext,
    focusedEventId,
    totalGroups,
    valueVisibility.groupCount,
    valueVisibility.next24h,
    statusSnapshot.soonCount,
  ]);

  const headerSubtitle = useMemo(() => {
    const visibleEvents = filterVisibleEvents(events, {
      declinedIds: declinedEventIds,
      hiddenIds: hiddenEventIds,
    });

    if (visibleEvents.length === 0) {
      return "Revisa planes, respuestas y decisiones abiertas desde una sola bandeja.";
    }

    const personal = visibleEvents.filter((e) => !e.group_id).length;
    const groupEvents = visibleEvents.filter((e) => !!e.group_id).length;

    return `${personal} personal${personal === 1 ? "" : "es"} · ${groupEvents} compartido${
      groupEvents === 1 ? "" : "s"
    }. Entra rápido a lo que sigue, lo compartido o lo ya cerrado.`;
  }, [events, declinedEventIds, hiddenEventIds]);

  function toggleSelection(id: string) {
    setSelectedIds((prev) => {
      const next = new Set(prev);
      if (next.has(id)) next.delete(id);
      else next.add(id);
      return next;
    });
  }

  const refreshData = useCallback(async (viewOverride: ViewMode = "upcoming") => {
    try {
      setLoading(true);

      const [eventsRes, groupsRes, declinedRes, conflictResMap, ignoredKeys] = await Promise.all([
        getEventsForView(viewOverride).catch((err) => {
          console.error("Error refrescando getMyEventsInRange:", err);
          return [] as DbEventRow[];
        }),
        getMyGroups().catch((err) => {
          console.error("Error refrescando getMyGroups:", err);
          return [] as GroupRow[];
        }),
        getMyDeclinedEventIds().catch((err) => {
          console.error("Error refrescando getMyDeclinedEventIds:", err);
          return new Set<string>();
        }),
        getMyConflictResolutionsMap().catch((err) => {
          console.error("Error refrescando getMyConflictResolutionsMap:", err);
          return {};
        }),
        getIgnoredConflictKeys().catch((err) => {
          console.error("Error refrescando getIgnoredConflictKeys:", err);
          return new Set<string>();
        }),
      ]);

      const groupsById = new Map(groupsRes.map((g) => [String(g.id), g]));

      const withGroup: EventWithGroup[] = eventsRes.map((e) => ({
        ...e,
        group: e.group_id ? groupsById.get(String(e.group_id)) ?? null : null,
      }));

      setEvents(withGroup);
      setGroups(groupsRes);
      setDeclinedEventIds(declinedRes);
      setResolvedConflictMap(conflictResMap ?? {});
      setIgnoredConflictKeys(ignoredKeys instanceof Set ? ignoredKeys : new Set());
      setLoadedView(viewOverride);
} catch (err: unknown) {
  console.error("Error refrescando eventos:", err);
  setToast({
    type: "error",
    message:
      err instanceof Error
        ? err.message
        : "No se pudieron refrescar los eventos. Intenta de nuevo.",
  });
}
    finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (booting) return;
    if (filters.view === loadedView) return;

    void refreshData(filters.view);
  }, [booting, filters.view, loadedView, refreshData]);

  useEffect(() => {
    if (booting) return;

    const refreshCurrentView = () => {
      void refreshData(filters.view);
    };

    const onVisibility = () => {
      if (document.visibilityState === "visible") refreshCurrentView();
    };

    window.addEventListener("sp:events-changed", refreshCurrentView as EventListener);
    window.addEventListener("focus", refreshCurrentView);
    document.addEventListener("visibilitychange", onVisibility);

    return () => {
      window.removeEventListener("sp:events-changed", refreshCurrentView as EventListener);
      window.removeEventListener("focus", refreshCurrentView);
      document.removeEventListener("visibilitychange", onVisibility);
    };
  }, [booting, filters.view, refreshData]);

  async function handleDeleteSelected() {
    if (selectedIds.size === 0) return;

    if (
      !window.confirm(
        `¿Eliminar ${selectedIds.size} evento${
          selectedIds.size === 1 ? "" : "s"
        } de tu lista? Esta acción no se puede deshacer.`
      )
    ) {
      return;
    }

    try {
      setDeleting(true);

      const idsArray = Array.from(selectedIds);
      const result = await deleteEventsByIdsDetailed(idsArray);

      if (result.deletedCount > 0) {
        const removedIds = new Set(result.ownIds.map(String));

        setEvents((prev) =>
          prev.filter((event) => !removedIds.has(String(event.id)))
        );
        setSelectedIds((prev) => {
          const next = new Set(prev);
          for (const id of removedIds) next.delete(id);
          return next;
        });
      }

      if (result.deletedCount > 0 && result.blockedIds.length > 0) {
        setToast({
          type: "success",
          message:
            `Se eliminaron ${result.deletedCount} evento${
              result.deletedCount === 1 ? "" : "s"
            }, pero ${result.blockedIds.length} no se pudo${
              result.blockedIds.length === 1 ? "" : "ieron"
            } borrar porque no te pertenece${
              result.blockedIds.length === 1 ? "" : "n"
            } o no está permitido.`,
        });
        return;
      }

      if (result.deletedCount > 0) {
        setToast({
          type: "success",
          message: `Se eliminaron ${result.deletedCount} evento${
            result.deletedCount === 1 ? "" : "s"
          } correctamente.`,
        });
        return;
      }

      throw new Error(
        "No se pudo eliminar la selección con tu sesión actual. Puede incluir eventos de otra persona o bloqueados por permisos."
      );
} catch (err: unknown) {
  console.error("Error al eliminar eventos:", err);
  setToast({
    type: "error",
    message:
      err instanceof Error
        ? err.message
        : "No se pudieron eliminar esos eventos. Intenta de nuevo.",
  });
}
    finally {
      setDeleting(false);
    }
  }

  async function sendTodayDigest() {
    try {
      setSendingDigest(true);
      await new Promise((resolve) => setTimeout(resolve, 1200));
      setToast({
        type: "success",
        message: "Se envió un resumen simulado de tus eventos de hoy.",
      });
 } catch (err: unknown) {
  console.error("Error enviando digest:", err);
  setToast({
    type: "error",
    message:
      err instanceof Error
        ? err.message
        : "No se pudo enviar el resumen hoy. Intenta nuevamente.",
  });
}
    finally {
      setSendingDigest(false);
    }
  }

  useEffect(() => {
    if (!toast) return;
    const id = setTimeout(() => setToast(null), 3500);
    return () => clearTimeout(id);
  }, [toast]);

  useEffect(() => {
    setMobileVisibleCount(MOBILE_INITIAL_VISIBLE);
  }, [filters.view, filters.scope, filters.query]);

  const anySelected = selectedIds.size > 0;
  const compactHeaderSubtitle = isMobile
    ? events.length === 0
      ? "Bandeja simple para planes y decisiones."
      : `${filteredEvents.length} evento${filteredEvents.length === 1 ? "" : "s"} visibles.`
    : headerSubtitle;

  const focusAside = useMemo<FocusAsideState>(() => {
    if (isPendingResponsesFocus) {
      if (pendingResponseEvent) {
        return {
          eyebrow: "Respuesta pendiente",
          title: "Este plan necesita revisión",
          body: `${pendingResponseEvent.title || "Este plan"} recibió una respuesta externa. Lo resaltamos abajo para que puedas revisar el estado exacto.`,
          cta: "Abrir plan",
          action: "focused",
        };
      }

      return {
        eyebrow: "Respuesta pendiente",
        title: loading ? "Buscando el plan" : "No encontramos ese plan en la lista",
        body: loading
          ? "Estamos cargando la bandeja para llevarte directo a la alerta."
          : "Puede estar fuera del rango visible o ya haber sido cerrado. Actualiza la lista o vuelve al Panel.",
      };
    }

    if (!loading && coordinationInbox.conflictEventCount > 0) {
      return {
        eyebrow: "Tu foco ahora",
        title: "Hay choques por resolver",
        body: "Empieza por las decisiones que pueden bloquear la coordinación compartida.",
        cta: "Resolver choques",
        action: "conflicts",
      };
    }

    if (!loading && urgentEvents.length > 0) {
      return {
        eyebrow: "Tu foco ahora",
        title: `${urgentEvents.length} plan${urgentEvents.length === 1 ? "" : "es"} cerca`,
        body: "Revisa primero lo más próximo para que nada se quede abierto a última hora.",
        cta: "Ver próximos",
        action: "upcoming",
      };
    }

    if (statusSnapshot.nextCount > 0) {
      return {
        eyebrow: "Tu foco ahora",
        title: "Todo al día",
        body: "No hay acciones abiertas. Lo que viene queda ordenado debajo.",
      };
    }

    return {
      eyebrow: "Tu foco ahora",
      title: "Todavía no hay planes visibles",
      body: "Crea el primer evento para convertir esta pantalla en una bandeja útil de coordinación.",
      cta: "Crear evento",
      action: "create",
    };
  }, [
    isPendingResponsesFocus,
    pendingResponseEvent,
    loading,
    coordinationInbox.conflictEventCount,
    urgentEvents.length,
    statusSnapshot.nextCount,
  ]);

  const handleFocusAsideClick = () => {
    if (focusAside.action === "focused" && focusedEventId) {
      router.push(`/events/new/details?eventId=${encodeURIComponent(String(focusedEventId))}`);
      return;
    }

    if (focusAside.action === "conflicts") {
      router.push("/conflicts/detected");
      return;
    }

    if (focusAside.action === "upcoming") {
      setFilters((f) => ({ ...f, view: "upcoming", scope: "all" }));
      return;
    }

    if (focusAside.action === "create") {
      router.push("/events/new/details?type=personal");
    }
  };

  const handleInboxLaneClick = (action: InboxLaneAction) => {
    if (action === "conflicts") {
      router.push("/conflicts/detected");
      return;
    }

    if (action === "attention") {
      if (coordinationInbox.conflictEventCount > 0) {
        router.push("/conflicts/detected");
        return;
      }

      setFilters((f) => ({ ...f, view: "upcoming", scope: "groups" }));
      return;
    }

    if (action === "history") {
      setFilters((f) => ({ ...f, view: "history", scope: "all" }));
      return;
    }

    setFilters((f) => ({ ...f, view: "upcoming", scope: "all" }));
  };

  const showDigestButton = events.length > 0 && !anySelected;
  const showValueRail =
    false &&
    !isMobile &&
    valueVisibility.hasValue &&
    urgentEvents.length === 0 &&
    !premiumContext;
  const showPremiumRail =
    !isMobile &&
    !!premiumContext &&
    urgentEvents.length === 0;

  if (booting) {
    return (
      <MobileScaffold maxWidth={1120} style={S.pageBg}>
        <Section>
          <PremiumHeader
            hideUpgradeCta
            title="Eventos"
            subtitle="Preparando tu bandeja de coordinación."
          />
          <Card style={S.cardShell}>
            <div style={S.loadingRow}>
              <div style={S.loadingDot} />
              <div>
                <div style={S.loadingTitle}>Cargando tus eventos…</div>
                <div style={S.loadingSub}>Preparando tu lista para hoy</div>
              </div>
            </div>
          </Card>
        </Section>
      </MobileScaffold>
    );
  }

  return (
    <MobileScaffold maxWidth={1120} style={S.pageBg}>
      {toast && (
        <div style={S.toastViewport}>
          <div
            style={{
              ...S.toastPill,
              background:
                toast.type === "success"
                  ? "rgba(34,197,94,0.95)"
                  : "rgba(248,113,113,0.95)",
            }}
          >
            {toast.message}
          </div>
        </div>
      )}

      <Section>
        <PremiumHeader hideUpgradeCta title="Eventos" subtitle={compactHeaderSubtitle} />

        <Card style={{ ...S.cardShell, ...(isMobile ? S.cardShellMobile : null) }} className="spEvt-card">
          <div style={S.titleRow}>
            <div style={S.heroCopy}>
              <div style={S.kicker}>Planes y decisiones</div>
              <h1 style={S.h1}>Bandeja de coordinación</h1>
              <p style={S.sub}>
                Planes, respuestas y decisiones en un solo lugar.
              </p>
            </div>
          </div>

          <div
            style={{
              ...S.focusActionBar,
              ...(isMobile ? S.focusActionBarMobile : null),
            }}
          >
            <div style={S.focusActionCopy}>
              <div style={S.factLabel}>{focusAside.eyebrow}</div>
              <div style={S.focusActionTitle}>{focusAside.title}</div>
              <div style={S.focusActionHint}>{focusAside.body}</div>
            </div>
            {focusAside.cta ? (
              <button type="button" style={S.focusActionCta} onClick={handleFocusAsideClick}>
                {focusAside.cta}
              </button>
            ) : null}
          </div>

          <div style={S.inboxShell}>
            <div style={S.inboxHeader}>
              <div>
                <div style={S.inboxEyebrow}>Coordination Inbox</div>
                <div style={S.inboxTitle}>Lo importante primero.</div>
              </div>
            </div>

            <div style={{ ...S.inboxGrid, ...(isMobile ? S.inboxGridMobile : null) }}>
              {inboxLanes.map((lane) => {
                const active =
                  (lane.action === "upcoming" && filters.view === "upcoming" && filters.scope === "all") ||
                  (lane.action === "history" && filters.view === "history") ||
                  (lane.action === "attention" && filters.view === "upcoming" && filters.scope === "groups");

                return (
                  <button
                    key={lane.action}
                    type="button"
                    onClick={() => handleInboxLaneClick(lane.action)}
                    style={{
                      ...S.inboxLane,
                      ...(active ? S.inboxLaneActive : null),
                      ...(lane.accent === "conflict" && lane.count > 0 ? S.inboxLaneConflict : null),
                    }}
                  >
                    <div style={S.inboxLaneTop}>
                      <span style={S.inboxLaneEyebrow}>{lane.eyebrow}</span>
                      <span style={S.inboxLaneCount}>{lane.count}</span>
                    </div>
                    <div style={S.inboxLaneTitle}>{lane.title}</div>
                    <div style={S.inboxLaneBody}>{lane.body}</div>
                  </button>
                );
              })}
            </div>
          </div>

          {!loading && urgentEvents.length > 0 ? (
            <div style={S.focusRail}>
              <div style={S.focusHeader}>
                <div>
                  <div style={S.focusEyebrow}>Foco operativo</div>
                  <div style={S.focusTitle}>Lo que pide movimiento ahora</div>
                </div>
                <div style={S.focusCount}>
                  {urgentEvents.length} evento{urgentEvents.length === 1 ? "" : "s"}
                </div>
              </div>

              <div style={S.focusList}>
                {urgentEvents.slice(0, isMobile ? 2 : 3).map((e) => (
                  <button
                    key={String(e.id)}
                    type="button"
                    style={S.focusItem}
                    onClick={() =>
                      router.push(`/events?focusEventId=${encodeURIComponent(String(e.id))}`)
                    }
                  >
                    <div style={S.focusItemMain}>
                      <div style={S.focusName}>{e.title || "Sin título"}</div>
                      <div style={S.focusMeta}>
                        {shortDateLabel(e.start)} · {shortTimeLabel(e.start)}
                        {e.group?.name ? ` · ${e.group.name}` : " · Personal"}
                      </div>
                    </div>
                  </button>
                ))}
              </div>
            </div>
          ) : null}

          {showValueRail ? (
            <div style={S.secondaryRail}>
              <div>
                <div style={S.secondaryEyebrow}>Lectura rápida</div>
                <div style={S.secondaryTitle}>Tu lista ya tiene contexto útil.</div>
                <div style={S.secondarySub}>
                  {valueVisibility.personalCount} personales · {valueVisibility.groupCount} compartidos · {statusSnapshot.soonCount} por revisar pronto.
                </div>
              </div>
            </div>
          ) : null}

          {showPremiumRail && premiumContext ? (
            <div style={S.premiumRail}>
              <div style={S.premiumCopy}>
                <div style={S.premiumEyebrow}>{premiumContext.eyebrow}</div>
                <div style={S.premiumTitle}>{premiumContext.title}</div>
                <div style={S.premiumSub}>{premiumContext.body}</div>
              </div>
              <button
                type="button"
                style={S.premiumBtn}
                onClick={() => router.push("/planes")}
              >
                {premiumContext.cta}
              </button>
            </div>
          ) : null}

          {isPendingResponsesFocus ? (
            <div style={S.pendingResponseRail}>
              <div style={S.pendingResponseCopy}>
                <div style={S.pendingResponseEyebrow}>Alerta abierta desde Panel</div>
                <div style={S.pendingResponseTitle}>
                  {pendingResponseEvent
                    ? pendingResponseEvent.title || "Plan compartido"
                    : loading
                      ? "Buscando el plan pendiente"
                      : "No encontramos el plan pendiente"}
                </div>
                <div style={S.pendingResponseSub}>
                  {pendingResponseEvent
                    ? "Este es el plan que recibió una respuesta externa. Está resaltado en la lista para que revises el estado y decidas el siguiente paso."
                    : "La alerta puede haberse cerrado, estar fuera del rango visible o no tener permisos con esta sesión."}
                </div>
              </div>

              <div style={S.pendingResponseActions}>
                {pendingResponseEvent ? (
                  <button
                    type="button"
                    style={S.pendingResponsePrimary}
                    onClick={() =>
                      router.push(
                        `/events/new/details?eventId=${encodeURIComponent(String(pendingResponseEvent.id))}`
                      )
                    }
                  >
                    Abrir plan
                  </button>
                ) : null}

                <button
                  type="button"
                  style={S.pendingResponseSecondary}
                  onClick={() => router.push("/panel")}
                >
                  Volver al Panel
                </button>
              </div>
            </div>
          ) : null}

          <div style={{ ...S.filtersShell, ...(isMobile ? S.filtersShellMobile : null) }}>
            <div style={S.filtersGroup}>
              <div style={S.filtersLabel}>Vista</div>
              <SegmentedChips<ViewMode>
                options={[
                  { value: "upcoming", label: "Próximos" },
                  { value: "history", label: "Ya pasaron" },
                  { value: "all", label: "Todo visible" },
                ]}
                value={filters.view}
                onChange={(view) => setFilters((f) => ({ ...f, view }))}
              />
            </div>

            <div style={S.filtersGroup}>
              <div style={S.filtersLabel}>Origen</div>
              <SegmentedChips<Scope>
                options={[
                  { value: "all", label: "Todo visible" },
                  { value: "personal", label: "Personal" },
                  { value: "groups", label: "Compartido" },
                ]}
                value={filters.scope}
                onChange={(scope) => setFilters((f) => ({ ...f, scope }))}
              />
            </div>

            <label style={S.searchWrap}>
              <span style={S.searchLabel}>Buscar</span>
              <input
                type="search"
                inputMode="search"
                autoCapitalize="sentences"
                autoCorrect="off"
                spellCheck={false}
                value={filters.query}
                onChange={(e) => setFilters((f) => ({ ...f, query: e.target.value }))}
                placeholder="Buscar por título, nota o espacio compartido"
                style={S.searchInput}
              />
            </label>
          </div>

          <div style={S.advancedShell}>
            <button
              type="button"
              style={S.advancedToggle}
              onClick={() => setShowAdvancedActions((current) => !current)}
            >
              {showAdvancedActions ? "Ocultar herramientas" : "Herramientas secundarias"}
            </button>

            {showAdvancedActions ? (
              <div style={S.advancedActions}>
                <button
                  type="button"
                  onClick={() => refreshData(filters.view)}
                  disabled={loading}
                  style={S.digestBtn}
                >
                  {loading ? "Actualizando lista…" : "Actualizar lista"}
                </button>

                {showDigestButton ? (
                  <button
                    type="button"
                    onClick={sendTodayDigest}
                    disabled={sendingDigest}
                    style={{ ...S.digestBtn, ...(sendingDigest ? S.digestBtnLoading : {}) }}
                  >
                    {sendingDigest ? "Preparando resumen…" : "Probar resumen de hoy"}
                  </button>
                ) : null}
              </div>
            ) : null}
          </div>

          {anySelected ? (
            <div style={S.bulkBar}>
              <span style={S.bulkLabel}>
                {selectedIds.size} evento{selectedIds.size === 1 ? "" : "s"} seleccionado{selectedIds.size === 1 ? "" : "s"}
              </span>
              <button
                type="button"
                onClick={handleDeleteSelected}
                disabled={deleting}
                style={S.bulkDelete}
              >
                {deleting ? "Eliminando…" : "Eliminar selección"}
              </button>
            </div>
          ) : null}

          {loading ? (
            <div style={S.loadingList}>
              <div style={S.loadingRow}>
                <div style={S.loadingDot} />
                <div>
                  <div style={S.loadingTitle}>Cargando eventos…</div>
                  <div style={S.loadingSub}>Un momento, por favor.</div>
                </div>
              </div>
            </div>
          ) : filteredEvents.length === 0 ? (
            <EventsEmptyState
              onCreateFirstEvent={() => router.push("/events/new/details?type=personal")}
            />
          ) : (
            <>
              <EventsTimeline
                events={timelineEvents}
                selectedIds={selectedIds}
                focusedEventId={focusedEventId}
                onToggleSelected={toggleSelection}
                onEventsRemoved={(removedIds) => {
                  const removed = new Set(removedIds.map(String));
                  setEvents((prev) =>
                    prev.filter((event) => !removed.has(String(event.id)))
                  );
                  setSelectedIds((prev) => {
                    const next = new Set(prev);
                    for (const id of removed) next.delete(id);
                    return next;
                  });
                }}
              />

              {hasMoreTimelineEvents ? (
                <div style={S.mobileLoadMoreWrap}>
                  <button
                    type="button"
                    onClick={() =>
                      setMobileVisibleCount((current) => current + MOBILE_LOAD_MORE_STEP)
                    }
                    style={S.mobileLoadMoreBtn}
                  >
                    Ver {Math.min(MOBILE_LOAD_MORE_STEP, filteredEvents.length - timelineEvents.length)} más
                  </button>
                  <div style={S.mobileLoadMoreHint}>
                    Mostrando {timelineEvents.length} de {filteredEvents.length} eventos
                  </div>
                </div>
              ) : null}
            </>
          )}
        </Card>


      </Section>

      <style jsx>{`
        @media (max-width: 767px) {
          .spEvt-card {
            padding: 14px !important;
          }

          .spEvt-factBox {
            min-width: 100% !important;
            max-width: none !important;
            padding: 12px !important;
          }
        }
      `}</style>
    </MobileScaffold>
  );
}

const S: Record<string, React.CSSProperties> = {
  pageBg: {
    minHeight: "100vh",
    background:
      "radial-gradient(1200px 620px at 20% -10%, rgba(56,189,248,0.14), transparent 60%), radial-gradient(900px 520px at 100% 0%, rgba(124,58,237,0.12), transparent 58%), #050816",
  },
  cardShell: {
    borderRadius: 24,
    border: "1px solid rgba(255,255,255,0.08)",
    background: "rgba(10,15,30,0.76)",
    backdropFilter: "blur(16px)",
    boxShadow: "0 18px 60px rgba(0,0,0,0.28)",
    padding: 18,
  },
  toastViewport: {
    position: "fixed",
    left: 0,
    right: 0,
    bottom: 80,
    display: "flex",
    justifyContent: "center",
    pointerEvents: "none",
    zIndex: 30,
  },
  toastPill: {
    pointerEvents: "auto",
    borderRadius: 999,
    padding: "10px 14px",
    fontSize: 13,
    fontWeight: 700,
    minWidth: 0,
    overflowWrap: "anywhere",
    color: "white",
    boxShadow: "0 18px 40px rgba(0,0,0,0.65)",
  },
  titleRow: {
    display: "block",
    minWidth: 0,
  },
  heroCopy: {
    minWidth: 0,
    maxWidth: 860,
  },
  kicker: {
    fontSize: 11,
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(125,211,252,0.88)",
  },
  h1: {
    margin: "8px 0 0",
    fontSize: "clamp(28px, 4vw, 40px)",
    lineHeight: 1.03,
    letterSpacing: "-0.04em",
    fontWeight: 950,
    color: "rgba(255,255,255,0.98)",
  },
  sub: {
    margin: "10px 0 0",
    maxWidth: 760,
    fontSize: 14,
    lineHeight: 1.55,
    color: "rgba(226,232,240,0.76)",
    fontWeight: 600,
  },
  factBox: {
    minWidth: 0,
    maxWidth: 280,
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.04)",
    padding: 14,
    display: "grid",
    gap: 10,
  },
  factLabel: {
    fontSize: 11,
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(255,255,255,0.66)",
  },
  factTitle: {
    fontSize: 17,
    lineHeight: 1.18,
    fontWeight: 950,
    letterSpacing: "-0.02em",
    color: "rgba(255,255,255,0.98)",
  },
  factCta: {
    minHeight: 40,
    borderRadius: 14,
    border: "1px solid rgba(96,165,250,0.30)",
    background: "rgba(59,130,246,0.16)",
    color: "rgba(255,255,255,0.98)",
    fontSize: 13,
    fontWeight: 900,
    cursor: "pointer",
  },
  factGrid: {
    display: "grid",
    gap: 8,
  },
  factItem: {
    display: "flex",
    alignItems: "center",
    gap: 8,
    fontSize: 13,
    fontWeight: 700,
    minWidth: 0,
    overflowWrap: "anywhere",
    color: "rgba(255,255,255,0.92)",
  },
  factDotPersonal: {
    width: 8,
    height: 8,
    borderRadius: 999,
    background: "rgba(251,191,36,0.95)",
    boxShadow: "0 0 0 5px rgba(251,191,36,0.12)",
  },
  factDotGroup: {
    width: 8,
    height: 8,
    borderRadius: 999,
    background: "rgba(56,189,248,0.95)",
    boxShadow: "0 0 0 5px rgba(56,189,248,0.12)",
  },
  factHint: {
    fontSize: 12,
    lineHeight: 1.5,
    color: "rgba(226,232,240,0.68)",
    fontWeight: 600,
  },
  focusActionBar: {
    marginTop: 16,
    borderRadius: 18,
    border: "1px solid rgba(96,165,250,0.18)",
    background:
      "linear-gradient(135deg, rgba(37,99,235,0.14), rgba(255,255,255,0.035))",
    padding: "13px 14px",
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 14,
  },
  focusActionBarMobile: {
    alignItems: "stretch",
    flexDirection: "column",
  },
  focusActionCopy: {
    minWidth: 0,
    display: "grid",
    gap: 4,
  },
  focusActionTitle: {
    fontSize: 16,
    lineHeight: 1.22,
    fontWeight: 950,
    letterSpacing: "-0.02em",
    color: "rgba(255,255,255,0.98)",
  },
  focusActionHint: {
    fontSize: 12,
    lineHeight: 1.45,
    color: "rgba(226,232,240,0.68)",
    fontWeight: 650,
  },
  focusActionCta: {
    minHeight: 38,
    borderRadius: 13,
    border: "1px solid rgba(96,165,250,0.30)",
    background: "rgba(59,130,246,0.16)",
    color: "rgba(255,255,255,0.98)",
    fontSize: 12,
    fontWeight: 900,
    cursor: "pointer",
    padding: "0 14px",
    whiteSpace: "nowrap",
  },

  inboxShell: {
    marginTop: 16,
    borderRadius: 20,
    border: "1px solid rgba(255,255,255,0.08)",
    background: "rgba(255,255,255,0.035)",
    padding: 12,
    display: "grid",
    gap: 10,
  },
  inboxHeader: {
    display: "flex",
    justifyContent: "space-between",
    gap: 12,
    alignItems: "flex-start",
    flexWrap: "wrap",
  },
  inboxEyebrow: {
    fontSize: 11,
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(125,211,252,0.88)",
  },
  inboxTitle: {
    marginTop: 4,
    fontSize: 15,
    lineHeight: 1.3,
    fontWeight: 950,
    color: "rgba(255,255,255,0.97)",
  },
  inboxHint: {
    borderRadius: 999,
    padding: "7px 10px",
    background: "rgba(255,255,255,0.04)",
    border: "1px solid rgba(255,255,255,0.08)",
    color: "rgba(226,232,240,0.66)",
    fontSize: 11,
    fontWeight: 850,
  },
  inboxGrid: {
    display: "grid",
    gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
    gap: 10,
  },
  inboxGridMobile: {
    gridTemplateColumns: "repeat(2, minmax(0, 1fr))",
    gap: 8,
  },
  inboxLane: {
    width: "100%",
    minWidth: 0,
    minHeight: 94,
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.08)",
    background: "rgba(15,23,42,0.46)",
    padding: "10px 10px",
    textAlign: "left",
    color: "rgba(255,255,255,0.95)",
    cursor: "pointer",
    display: "grid",
    alignContent: "start",
    gap: 5,
  },
  inboxLaneActive: {
    border: "1px solid rgba(96,165,250,0.28)",
    background: "linear-gradient(135deg, rgba(37,99,235,0.18), rgba(255,255,255,0.04))",
    boxShadow: "0 0 0 1px rgba(96,165,250,0.10) inset",
  },
  inboxLaneConflict: {
    border: "1px solid rgba(251,113,133,0.30)",
    background: "linear-gradient(135deg, rgba(127,29,29,0.28), rgba(15,23,42,0.50))",
  },
  inboxLaneTop: {
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 8,
  },
  inboxLaneEyebrow: {
    fontSize: 10,
    fontWeight: 950,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(226,232,240,0.58)",
  },
  inboxLaneCount: {
    minWidth: 26,
    height: 26,
    borderRadius: 999,
    display: "inline-flex",
    alignItems: "center",
    justifyContent: "center",
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.055)",
    fontSize: 12,
    fontWeight: 950,
    color: "rgba(255,255,255,0.98)",
  },
  inboxLaneTitle: {
    fontSize: 13,
    lineHeight: 1.2,
    fontWeight: 950,
    color: "rgba(255,255,255,0.98)",
  },
  inboxLaneBody: {
    fontSize: 11,
    lineHeight: 1.3,
    fontWeight: 650,
    color: "rgba(226,232,240,0.68)",
    overflowWrap: "anywhere",
  },
  focusRail: {
    marginTop: 16,
    borderRadius: 18,
    border: "1px solid rgba(251,191,36,0.22)",
    background:
      "linear-gradient(135deg, rgba(120,53,15,0.42), rgba(30,41,59,0.62))",
    padding: 14,
    display: "grid",
    gap: 12,
  },
  focusHeader: {
    display: "flex",
    justifyContent: "space-between",
    gap: 12,
    alignItems: "center",
    flexWrap: "wrap",
  },
  focusEyebrow: {
    fontSize: 11,
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(253,224,71,0.92)",
  },
  focusTitle: {
    marginTop: 4,
    fontSize: 16,
    fontWeight: 900,
    color: "rgba(255,255,255,0.97)",
  },
  focusCount: {
    borderRadius: 999,
    padding: "8px 10px",
    background: "rgba(251,191,36,0.16)",
    border: "1px solid rgba(251,191,36,0.20)",
    color: "rgba(254,243,199,0.98)",
    fontSize: 12,
    fontWeight: 900,
  },
  focusList: {
    display: "grid",
    gap: 8,
  },
  focusItem: {
    display: "flex",
    width: "100%",
    textAlign: "left",
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.08)",
    background: "rgba(255,255,255,0.04)",
    padding: "12px 13px",
    color: "rgba(255,255,255,0.95)",
    cursor: "pointer",
  },
  focusItemMain: {
    display: "grid",
    gap: 4,
    minWidth: 0,
  },
  focusName: {
    fontSize: 14,
    fontWeight: 900,
    lineHeight: 1.35,
  },
  focusMeta: {
    fontSize: 12,
    lineHeight: 1.45,
    color: "rgba(226,232,240,0.72)",
    fontWeight: 700,
  },
  secondaryRail: {
    marginTop: 14,
    borderRadius: 18,
    border: "1px solid rgba(56,189,248,0.18)",
    background: "rgba(8,47,73,0.34)",
    padding: "14px 15px",
  },
  secondaryEyebrow: {
    fontSize: 11,
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(125,211,252,0.88)",
  },
  secondaryTitle: {
    marginTop: 4,
    fontSize: 16,
    fontWeight: 900,
    color: "rgba(255,255,255,0.97)",
  },
  secondarySub: {
    marginTop: 5,
    fontSize: 13,
    lineHeight: 1.5,
    color: "rgba(226,232,240,0.74)",
    fontWeight: 600,
  },
  premiumRail: {
    marginTop: 14,
    borderRadius: 18,
    border: "1px solid rgba(196,181,253,0.24)",
    background:
      "linear-gradient(135deg, rgba(76,29,149,0.72), rgba(15,23,42,0.88))",
    padding: "14px 15px",
    display: "flex",
    justifyContent: "space-between",
    gap: 14,
    flexWrap: "wrap",
    alignItems: "center",
  },
  premiumCopy: {
    minWidth: 0,
    flex: "1 1 360px",
    display: "grid",
    gap: 4,
  },
  premiumEyebrow: {
    fontSize: 11,
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(233,213,255,0.92)",
  },
  premiumTitle: {
    fontSize: 16,
    lineHeight: 1.3,
    fontWeight: 900,
    color: "rgba(255,255,255,0.98)",
  },
  premiumSub: {
    fontSize: 13,
    lineHeight: 1.55,
    color: "rgba(243,232,255,0.84)",
    fontWeight: 600,
  },
  premiumBtn: {
    borderRadius: 999,
    padding: "10px 14px",
    border: "1px solid rgba(216,180,254,0.34)",
    background: "rgba(168,85,247,0.24)",
    color: "rgba(255,255,255,0.98)",
    fontSize: 13,
    fontWeight: 900,
    cursor: "pointer",
  },
  cardShellMobile: {
    padding: 14,
    borderRadius: 22,
  },
  factBoxMobile: {
    width: "100%",
    maxWidth: "100%",
    minWidth: 0,
  },
  pendingResponseRail: {
    marginTop: 14,
    borderRadius: 22,
    border: "1px solid rgba(251,191,36,0.22)",
    background:
      "linear-gradient(135deg, rgba(251,191,36,0.13), rgba(59,130,246,0.08))",
    padding: 14,
    display: "flex",
    alignItems: "center",
    justifyContent: "space-between",
    gap: 14,
    flexWrap: "wrap",
  },
  pendingResponseCopy: {
    minWidth: 0,
    flex: "1 1 280px",
  },
  pendingResponseEyebrow: {
    fontSize: 11,
    fontWeight: 950,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(253,230,138,0.92)",
  },
  pendingResponseTitle: {
    marginTop: 5,
    fontSize: 17,
    lineHeight: 1.18,
    fontWeight: 950,
    letterSpacing: "-0.02em",
    color: "rgba(255,255,255,0.98)",
    overflowWrap: "anywhere",
  },
  pendingResponseSub: {
    marginTop: 5,
    maxWidth: 760,
    fontSize: 13,
    lineHeight: 1.45,
    color: "rgba(226,232,240,0.78)",
    fontWeight: 650,
  },
  pendingResponseActions: {
    display: "flex",
    gap: 8,
    flexWrap: "wrap",
    justifyContent: "flex-end",
  },
  pendingResponsePrimary: {
    minHeight: 40,
    borderRadius: 14,
    border: "1px solid rgba(251,191,36,0.34)",
    background: "rgba(251,191,36,0.18)",
    color: "rgba(255,255,255,0.98)",
    fontSize: 13,
    fontWeight: 900,
    cursor: "pointer",
    padding: "0 14px",
  },
  pendingResponseSecondary: {
    minHeight: 40,
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(255,255,255,0.05)",
    color: "rgba(255,255,255,0.86)",
    fontSize: 13,
    fontWeight: 850,
    cursor: "pointer",
    padding: "0 14px",
  },
  filtersShell: {
    marginTop: 16,
    display: "grid",
    gridTemplateColumns: "minmax(0, 1fr) minmax(0, 1fr) minmax(260px, 1.25fr)",
    gap: 12,
    alignItems: "end",
  },
  filtersShellMobile: {
    gridTemplateColumns: "minmax(0, 1fr)",
    gap: 12,
  },
  filtersGroup: {
    display: "grid",
    gap: 8,
    minWidth: 0,
  },
  filtersLabel: {
    fontSize: 11,
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(255,255,255,0.66)",
  },
  segmentedWrap: {
    display: "flex",
    flexWrap: "wrap",
    gap: 8,
  },
  segmentedChip: {
    minHeight: 40,
    padding: "0 14px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.04)",
    color: "rgba(226,232,240,0.86)",
    fontSize: 13,
    fontWeight: 800,
    cursor: "pointer",
    maxWidth: "100%",
    whiteSpace: "normal",
  },
  segmentedChipActive: {
    border: "1px solid rgba(96,165,250,0.32)",
    background: "linear-gradient(135deg, rgba(59,130,246,0.28), rgba(124,58,237,0.18))",
    color: "rgba(255,255,255,0.98)",
    boxShadow: "0 0 0 1px rgba(96,165,250,0.12) inset",
  },
  searchWrap: {
    display: "grid",
    gap: 8,
  },
  searchLabel: {
    fontSize: 11,
    fontWeight: 900,
    textTransform: "uppercase",
    letterSpacing: "0.08em",
    color: "rgba(255,255,255,0.66)",
  },
  searchInput: {
    width: "100%",
    minHeight: 44,
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(255,255,255,0.035)",
    color: "rgba(255,255,255,0.96)",
    padding: "0 16px",
    fontSize: 16,
    outline: "none",
    boxSizing: "border-box",
  },
  summaryPillRow: {
    marginTop: 12,
    display: "flex",
    gap: 8,
    flexWrap: "wrap",
    alignItems: "center",
  },
  summaryPill: {
    minHeight: 34,
    padding: "0 11px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.04)",
    color: "rgba(226,232,240,0.90)",
    fontSize: 12,
    fontWeight: 900,
    cursor: "pointer",
  },
  summaryPillActive: {
    border: "1px solid rgba(96,165,250,0.28)",
    background: "rgba(59,130,246,0.14)",
    color: "rgba(255,255,255,0.98)",
  },
  summaryPillSoft: {
    minHeight: 34,
    padding: "0 11px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.08)",
    background: "rgba(255,255,255,0.03)",
    color: "rgba(226,232,240,0.70)",
    fontSize: 12,
    fontWeight: 850,
    display: "inline-flex",
    alignItems: "center",
  },
  advancedShell: {
    marginTop: 14,
    display: "grid",
    gap: 10,
  },
  advancedToggle: {
    width: "fit-content",
    minHeight: 36,
    padding: "0 12px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.04)",
    color: "rgba(255,255,255,0.90)",
    fontSize: 12,
    fontWeight: 900,
    cursor: "pointer",
  },
  advancedActions: {
    display: "flex",
    gap: 10,
    flexWrap: "wrap",
  },
  statusGrid: {
    marginTop: 16,
    display: "grid",
    gridTemplateColumns: "repeat(4, minmax(0, 1fr))",
    gap: 10,
  },
  statusCard: {
    display: "grid",
    gap: 6,
    textAlign: "left",
    minWidth: 0,
    borderRadius: 18,
    border: "1px solid rgba(255,255,255,0.08)",
    background: "rgba(255,255,255,0.035)",
    padding: "14px 14px",
    overflow: "hidden",
    color: "rgba(255,255,255,0.95)",
    cursor: "pointer",
    minHeight: 92,
  },
  statusCardActive: {
    border: "1px solid rgba(56,189,248,0.32)",
    boxShadow: "0 0 0 1px rgba(56,189,248,0.18) inset",
    background: "rgba(56,189,248,0.08)",
  },
  statusLabel: {
    fontSize: 12,
    lineHeight: 1.25,
    fontWeight: 900,
    color: "rgba(255,255,255,0.74)",
    overflowWrap: "anywhere",
  },
  statusValue: {
    fontSize: 24,
    lineHeight: 1.02,
    fontWeight: 950,
    letterSpacing: "-0.04em",
    color: "rgba(255,255,255,0.98)",
  },
  statusHint: {
    fontSize: 12,
    lineHeight: 1.45,
    color: "rgba(226,232,240,0.64)",
    fontWeight: 600,
  },
  auxRow: {
    marginTop: 14,
    display: "flex",
    justifyContent: "flex-start",
  },
  digestBtn: {
    minHeight: 42,
    padding: "0 14px",
    borderRadius: 14,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.05)",
    color: "rgba(255,255,255,0.95)",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 900,
  },
  digestBtnLoading: {
    opacity: 0.7,
    cursor: "wait",
  },
  bulkBar: {
    marginTop: 14,
    display: "flex",
    justifyContent: "space-between",
    alignItems: "center",
    gap: 12,
    flexWrap: "wrap",
    borderRadius: 16,
    border: "1px solid rgba(248,113,113,0.16)",
    background: "rgba(127,29,29,0.24)",
    padding: "12px 14px",
  },
  bulkLabel: {
    fontSize: 13,
    fontWeight: 800,
    color: "rgba(254,226,226,0.95)",
  },
  bulkDelete: {
    minHeight: 40,
    padding: "0 14px",
    borderRadius: 12,
    border: "1px solid rgba(252,165,165,0.22)",
    background: "rgba(248,113,113,0.18)",
    color: "rgba(255,255,255,0.98)",
    cursor: "pointer",
    fontSize: 13,
    fontWeight: 900,
  },
  loadingList: {
    marginTop: 14,
  },
  loadingRow: {
    display: "flex",
    alignItems: "center",
    gap: 12,
    padding: "14px 12px",
    borderRadius: 16,
    border: "1px solid rgba(255,255,255,0.10)",
    background: "rgba(255,255,255,0.03)",
  },
  loadingDot: {
    width: 10,
    height: 10,
    borderRadius: 999,
    background: "rgba(56,189,248,0.95)",
    boxShadow: "0 0 0 8px rgba(56,189,248,0.10)",
    flexShrink: 0,
  },
  loadingTitle: {
    fontSize: 14,
    fontWeight: 900,
    color: "rgba(255,255,255,0.96)",
  },
  loadingSub: {
    fontSize: 12,
    color: "rgba(226,232,240,0.66)",
    marginTop: 2,
    fontWeight: 600,
  },
  mobileLoadMoreWrap: {
    marginTop: 14,
    display: "grid",
    justifyItems: "center",
    gap: 8,
  },
  mobileLoadMoreBtn: {
    minHeight: 42,
    padding: "0 16px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(255,255,255,0.05)",
    color: "rgba(255,255,255,0.96)",
    fontSize: 13,
    fontWeight: 900,
    cursor: "pointer",
  },
  mobileLoadMoreHint: {
    fontSize: 12,
    color: "rgba(226,232,240,0.64)",
    fontWeight: 600,
  },
  footerSection: {
    display: "flex",
    justifyContent: "center",
    marginTop: 14,
    paddingBottom: 8,
  },
  refreshBtn: {
    minHeight: 42,
    padding: "0 16px",
    borderRadius: 999,
    border: "1px solid rgba(255,255,255,0.12)",
    background: "rgba(255,255,255,0.05)",
    color: "rgba(255,255,255,0.95)",
    fontSize: 13,
    fontWeight: 900,
    cursor: "pointer",
  },
};